var _i_curd_service_8cs =
[
    [ "Doc.Builder.Service.ICurdService", "interface_doc_1_1_builder_1_1_service_1_1_i_curd_service.html", "interface_doc_1_1_builder_1_1_service_1_1_i_curd_service" ]
];