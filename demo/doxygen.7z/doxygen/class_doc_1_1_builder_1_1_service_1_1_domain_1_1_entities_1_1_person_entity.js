var class_doc_1_1_builder_1_1_service_1_1_domain_1_1_entities_1_1_person_entity =
[
    [ "Age", "class_doc_1_1_builder_1_1_service_1_1_domain_1_1_entities_1_1_person_entity.html#aa34a9793ab07b89cc3fa0729813624b6", null ],
    [ "Gender", "class_doc_1_1_builder_1_1_service_1_1_domain_1_1_entities_1_1_person_entity.html#afdab59249760d8285183cf0bb7dbd70c", null ],
    [ "Id", "class_doc_1_1_builder_1_1_service_1_1_domain_1_1_entities_1_1_person_entity.html#a0f872b59ea854ba6378e9535d8751592", null ],
    [ "Name", "class_doc_1_1_builder_1_1_service_1_1_domain_1_1_entities_1_1_person_entity.html#aaa5361f969d6a81e5acdd494bc9da61b", null ]
];