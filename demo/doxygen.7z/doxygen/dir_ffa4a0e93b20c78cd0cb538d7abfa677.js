var dir_ffa4a0e93b20c78cd0cb538d7abfa677 =
[
    [ "CarEntity.cs", "_car_entity_8cs.html", null ],
    [ "PersonEntity.cs", "_person_entity_8cs.html", null ]
];