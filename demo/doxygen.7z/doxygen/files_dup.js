var files_dup =
[
    [ "docs", "dir_49e56c817e5e54854c35e136979f97ca.html", null ],
    [ "include", "dir_d44c64559bbebec7f509842c48db8b23.html", "dir_d44c64559bbebec7f509842c48db8b23" ]
];