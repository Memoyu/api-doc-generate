var class_doc_1_1_builder_1_1_core3_1_1_class1 =
[
    [ "GetInfo", "class_doc_1_1_builder_1_1_core3_1_1_class1.html#a0d29b24f85e0c77152156c787a1083f5", null ],
    [ "Name", "class_doc_1_1_builder_1_1_core3_1_1_class1.html#add2dd52afee42d2f5331da67b0cadd58", null ]
];