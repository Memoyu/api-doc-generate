var dir_c9bad66d435a6a159fac61b9a3bcfc83 =
[
    [ ".NETCoreApp,Version=v6.0.AssemblyAttributes.cs", "_doc_8_builder_8_service_2obj_2_debug_2net6_80_2_8_n_e_t_core_app_00_version_0av6_80_8_assembly_attributes_8cs.html", null ],
    [ "Doc.Builder.Service.AssemblyInfo.cs", "_doc_8_builder_8_service_8_assembly_info_8cs.html", null ],
    [ "Doc.Builder.Service.GlobalUsings.g.cs", "_doc_8_builder_8_service_8_global_usings_8g_8cs.html", null ]
];