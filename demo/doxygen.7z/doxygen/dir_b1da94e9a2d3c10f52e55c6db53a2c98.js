var dir_b1da94e9a2d3c10f52e55c6db53a2c98 =
[
    [ ".NETCoreApp,Version=v6.0.AssemblyAttributes.cs", "_doc_8_builder_8_service_2obj_2_debug_2net6_80_2_8_n_e_t_core_app_00_version_0av6_80_8_assembly_attributes_8cs.html", null ],
    [ "Doc.Builder.Service.AssemblyInfo.cs", "_doc_8_builder_8_service_8_assembly_info_8cs.html", null ],
    [ "Doc.Builder.Service.GlobalUsings.g.cs", "_doc_8_builder_8_service_8_global_usings_8g_8cs.html", null ]
];