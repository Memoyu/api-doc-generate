var namespaces_dup =
[
    [ "Doc", "namespace_doc.html", "namespace_doc" ]
];