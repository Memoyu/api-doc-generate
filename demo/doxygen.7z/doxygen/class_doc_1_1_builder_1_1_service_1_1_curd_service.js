var class_doc_1_1_builder_1_1_service_1_1_curd_service =
[
    [ "Del", "class_doc_1_1_builder_1_1_service_1_1_curd_service.html#a1ad0efd7302798e07a5c4bdec61cfe03", null ],
    [ "Get", "class_doc_1_1_builder_1_1_service_1_1_curd_service.html#a5979c6d39e6dc3674f8bf3095652e1b5", null ],
    [ "Get", "class_doc_1_1_builder_1_1_service_1_1_curd_service.html#aa12542765aafdb491657e44ade08b032", null ],
    [ "Insert", "class_doc_1_1_builder_1_1_service_1_1_curd_service.html#a9694d2448bed805940c2c6fadb838999", null ],
    [ "Update", "class_doc_1_1_builder_1_1_service_1_1_curd_service.html#a4c2f38490583526099378db5017ee619", null ]
];