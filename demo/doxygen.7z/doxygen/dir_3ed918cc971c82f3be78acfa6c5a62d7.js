var dir_3ed918cc971c82f3be78acfa6c5a62d7 =
[
    [ ".NETCoreApp,Version=v3.1.AssemblyAttributes.cs", "_8_n_e_t_core_app_00_version_0av3_81_8_assembly_attributes_8cs.html", null ],
    [ "Doc.Builder.Core3.AssemblyInfo.cs", "_doc_8_builder_8_core3_8_assembly_info_8cs.html", null ]
];