var dir_c4ad583e9958934b772f841d917ff8b0 =
[
    [ "netcoreapp3.1", "dir_64412f7916735d3bff317c666f07c6eb.html", "dir_64412f7916735d3bff317c666f07c6eb" ]
];