var namespace_doc_1_1_builder_1_1_service =
[
    [ "Domain", "namespace_doc_1_1_builder_1_1_service_1_1_domain.html", "namespace_doc_1_1_builder_1_1_service_1_1_domain" ],
    [ "CurdService", "class_doc_1_1_builder_1_1_service_1_1_curd_service.html", "class_doc_1_1_builder_1_1_service_1_1_curd_service" ],
    [ "ICurdService", "interface_doc_1_1_builder_1_1_service_1_1_i_curd_service.html", "interface_doc_1_1_builder_1_1_service_1_1_i_curd_service" ]
];