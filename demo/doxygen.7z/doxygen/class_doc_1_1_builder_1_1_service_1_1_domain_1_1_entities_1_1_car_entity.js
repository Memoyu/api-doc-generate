var class_doc_1_1_builder_1_1_service_1_1_domain_1_1_entities_1_1_car_entity =
[
    [ "Height", "class_doc_1_1_builder_1_1_service_1_1_domain_1_1_entities_1_1_car_entity.html#aad74519b2088617ff04dacbdd970d32c", null ],
    [ "Id", "class_doc_1_1_builder_1_1_service_1_1_domain_1_1_entities_1_1_car_entity.html#aa10377d3fce466b444f68a6be6a48924", null ],
    [ "Logo", "class_doc_1_1_builder_1_1_service_1_1_domain_1_1_entities_1_1_car_entity.html#a03f2b8009226b2cce87c9130b19624af", null ],
    [ "Width", "class_doc_1_1_builder_1_1_service_1_1_domain_1_1_entities_1_1_car_entity.html#a0650cbd0a0e4f5a510c129a7a9137f1a", null ]
];