var dir_ae1db452176d0f4d48dd8ade1d4b53df =
[
    [ "CarEntity.cs", "_car_entity_8cs.html", "_car_entity_8cs" ],
    [ "PersonEntity.cs", "_person_entity_8cs.html", "_person_entity_8cs" ]
];