var interface_doc_1_1_builder_1_1_service_1_1_i_curd_service =
[
    [ "Del", "interface_doc_1_1_builder_1_1_service_1_1_i_curd_service.html#a9bc80c085f42215bea25e6bd8b430ca1", null ],
    [ "Get", "interface_doc_1_1_builder_1_1_service_1_1_i_curd_service.html#acbdd54806a5147f0c02ae3dd5cca0e68", null ],
    [ "Get", "interface_doc_1_1_builder_1_1_service_1_1_i_curd_service.html#aeb566b51d3046cd2bcdad33cadc1e7ce", null ],
    [ "Insert", "interface_doc_1_1_builder_1_1_service_1_1_i_curd_service.html#aa4cfc1d0a5cb0d43a24d1364bdeb8908", null ],
    [ "Update", "interface_doc_1_1_builder_1_1_service_1_1_i_curd_service.html#a7717a4ec4bdaab9f1894a2e00f6468f6", null ]
];