var dir_fefea9faa92ec2bb3d117ec63b4bb411 =
[
    [ ".NETCoreApp,Version=v6.0.AssemblyAttributes.cs", "_doc_8_builder_8_timer_2obj_2_debug_2net6_80_2_8_n_e_t_core_app_00_version_0av6_80_8_assembly_attributes_8cs.html", null ],
    [ "Doc.Builder.Timer.AssemblyInfo.cs", "_doc_8_builder_8_timer_8_assembly_info_8cs.html", null ],
    [ "Doc.Builder.Timer.GlobalUsings.g.cs", "_doc_8_builder_8_timer_8_global_usings_8g_8cs.html", null ]
];