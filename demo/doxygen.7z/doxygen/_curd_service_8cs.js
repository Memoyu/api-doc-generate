var _curd_service_8cs =
[
    [ "Doc.Builder.Service.CurdService", "class_doc_1_1_builder_1_1_service_1_1_curd_service.html", "class_doc_1_1_builder_1_1_service_1_1_curd_service" ]
];