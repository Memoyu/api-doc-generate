var annotated_dup =
[
    [ "Doc", "namespace_doc.html", [
      [ "Builder", "namespace_doc_1_1_builder.html", [
        [ "Core3", "namespace_doc_1_1_builder_1_1_core3.html", [
          [ "Class1", "class_doc_1_1_builder_1_1_core3_1_1_class1.html", "class_doc_1_1_builder_1_1_core3_1_1_class1" ]
        ] ],
        [ "Lib", "namespace_doc_1_1_builder_1_1_lib.html", [
          [ "DEncrypt", "namespace_doc_1_1_builder_1_1_lib_1_1_d_encrypt.html", [
            [ "HashHelper", "class_doc_1_1_builder_1_1_lib_1_1_d_encrypt_1_1_hash_helper.html", "class_doc_1_1_builder_1_1_lib_1_1_d_encrypt_1_1_hash_helper" ],
            [ "MD5Helper", "class_doc_1_1_builder_1_1_lib_1_1_d_encrypt_1_1_m_d5_helper.html", null ]
          ] ],
          [ "TimeHelper", "class_doc_1_1_builder_1_1_lib_1_1_time_helper.html", null ]
        ] ],
        [ "Service", "namespace_doc_1_1_builder_1_1_service.html", [
          [ "Domain", "namespace_doc_1_1_builder_1_1_service_1_1_domain.html", [
            [ "Dtos", "namespace_doc_1_1_builder_1_1_service_1_1_domain_1_1_dtos.html", [
              [ "PersonDto", "class_doc_1_1_builder_1_1_service_1_1_domain_1_1_dtos_1_1_person_dto.html", "class_doc_1_1_builder_1_1_service_1_1_domain_1_1_dtos_1_1_person_dto" ]
            ] ],
            [ "Entities", "namespace_doc_1_1_builder_1_1_service_1_1_domain_1_1_entities.html", [
              [ "CarEntity", "class_doc_1_1_builder_1_1_service_1_1_domain_1_1_entities_1_1_car_entity.html", "class_doc_1_1_builder_1_1_service_1_1_domain_1_1_entities_1_1_car_entity" ],
              [ "PersonEntity", "class_doc_1_1_builder_1_1_service_1_1_domain_1_1_entities_1_1_person_entity.html", "class_doc_1_1_builder_1_1_service_1_1_domain_1_1_entities_1_1_person_entity" ]
            ] ]
          ] ],
          [ "CurdService", "class_doc_1_1_builder_1_1_service_1_1_curd_service.html", "class_doc_1_1_builder_1_1_service_1_1_curd_service" ],
          [ "ICurdService", "interface_doc_1_1_builder_1_1_service_1_1_i_curd_service.html", "interface_doc_1_1_builder_1_1_service_1_1_i_curd_service" ]
        ] ]
      ] ]
    ] ]
];