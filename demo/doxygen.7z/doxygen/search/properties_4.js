var searchData=
[
  ['logo_0',['Logo',['../class_doc_1_1_builder_1_1_service_1_1_domain_1_1_entities_1_1_car_entity.html#a03f2b8009226b2cce87c9130b19624af',1,'Doc::Builder::Service::Domain::Entities::CarEntity']]]
];
