var searchData=
[
  ['gender_0',['Gender',['../class_doc_1_1_builder_1_1_service_1_1_domain_1_1_dtos_1_1_person_dto.html#a8bc58c90a13fa4d74e29d1f0b4fa69b1',1,'Doc.Builder.Service.Domain.Dtos.PersonDto.Gender()'],['../class_doc_1_1_builder_1_1_service_1_1_domain_1_1_entities_1_1_person_entity.html#afdab59249760d8285183cf0bb7dbd70c',1,'Doc.Builder.Service.Domain.Entities.PersonEntity.Gender()']]]
];
