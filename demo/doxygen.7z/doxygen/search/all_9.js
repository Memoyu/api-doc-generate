var searchData=
[
  ['name_0',['Name',['../class_doc_1_1_builder_1_1_core3_1_1_class1.html#add2dd52afee42d2f5331da67b0cadd58',1,'Doc.Builder.Core3.Class1.Name()'],['../class_doc_1_1_builder_1_1_service_1_1_domain_1_1_dtos_1_1_person_dto.html#a1090b4e4977785618ef04e1b8c197313',1,'Doc.Builder.Service.Domain.Dtos.PersonDto.Name()'],['../class_doc_1_1_builder_1_1_service_1_1_domain_1_1_entities_1_1_person_entity.html#aaa5361f969d6a81e5acdd494bc9da61b',1,'Doc.Builder.Service.Domain.Entities.PersonEntity.Name()']]]
];
