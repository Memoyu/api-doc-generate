var searchData=
[
  ['del_0',['Del',['../class_doc_1_1_builder_1_1_service_1_1_curd_service.html#a1ad0efd7302798e07a5c4bdec61cfe03',1,'Doc.Builder.Service.CurdService.Del()'],['../interface_doc_1_1_builder_1_1_service_1_1_i_curd_service.html#a9bc80c085f42215bea25e6bd8b430ca1',1,'Doc.Builder.Service.ICurdService.Del()']]]
];
