var searchData=
[
  ['age_0',['Age',['../class_doc_1_1_builder_1_1_service_1_1_domain_1_1_dtos_1_1_person_dto.html#aedcfca802060c3b3a0df5067fe1bb3cb',1,'Doc.Builder.Service.Domain.Dtos.PersonDto.Age()'],['../class_doc_1_1_builder_1_1_service_1_1_domain_1_1_entities_1_1_person_entity.html#aa34a9793ab07b89cc3fa0729813624b6',1,'Doc.Builder.Service.Domain.Entities.PersonEntity.Age()']]]
];
