var searchData=
[
  ['icurdservice_2ecs_0',['ICurdService.cs',['../_i_curd_service_8cs.html',1,'']]]
];
