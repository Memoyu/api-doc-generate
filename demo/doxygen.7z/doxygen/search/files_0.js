var searchData=
[
  ['_2enetcoreapp_2cversion_3dv3_2e1_2eassemblyattributes_2ecs_0',['.NETCoreApp,Version=v3.1.AssemblyAttributes.cs',['../_8_n_e_t_core_app_00_version_0av3_81_8_assembly_attributes_8cs.html',1,'']]],
  ['_2enetcoreapp_2cversion_3dv6_2e0_2eassemblyattributes_2ecs_1',['.NETCoreApp,Version=v6.0.AssemblyAttributes.cs',['../_doc_8_builder_8_lib_2obj_2_debug_2net6_80_2_8_n_e_t_core_app_00_version_0av6_80_8_assembly_attributes_8cs.html',1,'(全局命名空间)'],['../_doc_8_builder_8_service_2obj_2_debug_2net6_80_2_8_n_e_t_core_app_00_version_0av6_80_8_assembly_attributes_8cs.html',1,'(全局命名空间)'],['../_doc_8_builder_8_timer_2obj_2_debug_2net6_80_2_8_n_e_t_core_app_00_version_0av6_80_8_assembly_attributes_8cs.html',1,'(全局命名空间)']]]
];
