var searchData=
[
  ['icurdservice_0',['ICurdService',['../interface_doc_1_1_builder_1_1_service_1_1_i_curd_service.html',1,'Doc::Builder::Service']]]
];
