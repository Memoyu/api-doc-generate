var searchData=
[
  ['insert_0',['Insert',['../class_doc_1_1_builder_1_1_service_1_1_curd_service.html#a9694d2448bed805940c2c6fadb838999',1,'Doc.Builder.Service.CurdService.Insert()'],['../interface_doc_1_1_builder_1_1_service_1_1_i_curd_service.html#aa4cfc1d0a5cb0d43a24d1364bdeb8908',1,'Doc.Builder.Service.ICurdService.Insert()']]]
];
