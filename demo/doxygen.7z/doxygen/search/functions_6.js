var searchData=
[
  ['update_0',['Update',['../class_doc_1_1_builder_1_1_service_1_1_curd_service.html#a4c2f38490583526099378db5017ee619',1,'Doc.Builder.Service.CurdService.Update()'],['../interface_doc_1_1_builder_1_1_service_1_1_i_curd_service.html#a7717a4ec4bdaab9f1894a2e00f6468f6',1,'Doc.Builder.Service.ICurdService.Update()']]]
];
